# P12 – Sport Data POC

## Présentation

Ce projet a été réalisé dans le cadre d'un Proof of Concept (POC) autour de la promotion du sport en entreprise.

L'objectif est de développer un pipeline ETL capable de traiter des données RH et sportives, d'enrichir ces données avec les distances domicile–entreprise grâce à Google Routes API, puis de calculer différents indicateurs liés à la mobilité durable et au bien-être des salariés.

Les données produites sont ensuite exploitées dans un tableau de bord Power BI.

---

## Fonctionnalités

Le projet permet de :

- importer les données RH et sportives ;
- calculer les distances domicile–entreprise via Google Routes API ;
- adapter le calcul d'itinéraire au moyen de déplacement déclaré ;
- mettre en cache les distances afin d'éviter les appels API inutiles ;
- générer des activités sportives simulées ;
- déterminer les salariés éligibles aux aides à la mobilité ;
- calculer les jours de bien-être et les primes associées ;
- générer des messages Slack ;
- exporter les résultats au format CSV ;
- visualiser les résultats dans Power BI.

---

## Structure du projet

```
data/
    raw/            Données sources
    processed/      Données générées
    cache/          Cache des distances Google

database/
    Gestion de la base SQLite

etl/
    Pipeline ETL

services/
    Services métier

simulation/
    Génération des activités sportives

tests/
    Tests unitaires

powerbi/
    Tableau de bord
```

---

## Technologies utilisées

- Python
- Pandas
- SQLite
- Google Routes API
- Pytest
- Power BI

---

## Installation

Installer les dépendances :

```bash
pip install -r requirements.txt
```

Créer un fichier `.env` à partir de `.env_sample.txt` puis renseigner la clé Google Routes API.

Pour exécuter les calculs réels Google Routes, configurer :

```dotenv
GOOGLE_MAPS_API_KEY=votre_cle
DISTANCE_PROVIDER=google
```

Pour une exécution locale sans appel externe, conserver :

```dotenv
DISTANCE_PROVIDER=mock
```

La clé API ne doit jamais être ajoutée au dépôt : le fichier `.env` est ignoré par Git.

### Règles métier

Le moyen de déplacement déclaré dans les données RH est considéré comme le moyen majoritaire du salarié. La distance calculée doit être cohérente avec cette déclaration :

- Marche : maximum 15 km ;
- Vélo/Trottinette/Autres : maximum 25 km ;
- autres modes : pas de prime sportive.

Une personne éligible reçoit une prime de 5 % de son salaire brut annuel. Les journées bien-être sont accordées à partir de 15 activités sur 12 mois, à raison de 5 jours.

---

## Exécution

Lancer le pipeline :

```bash
python -m etl.pipeline
```

Les résultats sont générés dans :

```
data/processed/
```

- employees.csv
- activities.csv
- slack_messages.csv

Les données sont aussi chargées dans `database/sport_poc.db`.

Le cache `data/cache/google_distances.csv` mémorise les distances par adresse et par mode de trajet (`DRIVE`, `WALK`, `BICYCLE`, `TRANSIT`). Il peut être supprimé pour forcer un recalcul complet.

Le pipeline bloque l'exécution lorsqu'il détecte des données RH ou des activités incohérentes : identifiant salarié dupliqué, adresse ou salaire invalide, moyen de déplacement inconnu, date invalide, distance d'activité négative ou salarié inconnu.

---

## Tests

Exécuter les tests :

```bash
python -m pytest
```

Le projet est couvert par une suite de tests unitaires permettant de valider les principaux composants (ETL, services, cache, API Google, génération des activités, etc.).

---

## Tableau de bord

Le fichier Power BI (`powerbi/P12.pbix`) permet de visualiser notamment :

- le nombre de salariés et de sportifs ;
- les activités générées ;
- les salariés éligibles à la mobilité ;
- les primes calculées ;
- les jours de bien-être ;
- la répartition des sports ;
- l'évolution mensuelle des activités.

---

## Test d'envoi Slack

Le pipeline génère les messages Slack mais ne les publie pas
automatiquement afin d'éviter l'envoi de l'historique simulé.

Créer un Incoming Webhook Slack puis renseigner :

```dotenv
SLACK_WEBHOOK_URL=https://hooks.slack.com/services/...
```
---
## Auteur

Projet réalisé dans le cadre du parcours de formation Data & IA.
